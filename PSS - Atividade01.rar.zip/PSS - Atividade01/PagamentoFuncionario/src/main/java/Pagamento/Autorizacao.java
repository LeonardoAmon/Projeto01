package Pagamento;

/**
 *
 * @author leou_
 */
public class Autorizacao {
    private String encarregado;
    private double valorPagamento;
    private boolean status;
    private boolean possibilidade1;
    private boolean possibilidade2;
    private boolean possibilidade3;
    private boolean possibilidade4;
   
    public Autorizacao(double valorPagamento, boolean status, boolean possibilidade1, boolean possibilidade2, boolean possibilidade3, boolean possibilidade4){
        this.valorPagamento = valorPagamento;
        this.possibilidade1 = possibilidade1;
        this.possibilidade2 = possibilidade2;
        this.possibilidade3 = possibilidade3;
        this.possibilidade4 = possibilidade4;
    }

    public String getEncarregado() {
        return encarregado;
    }
    
    public void setEncarregado(String encarregado) {
        this.encarregado = encarregado;
    }

    public double getValorPagamento() {
        return valorPagamento;
    }
    
    public void setValorPagamento(double valorPagamento) {
        this.valorPagamento = valorPagamento;
    }

    public boolean isStatus() {
        return status;
    }

    public void setStatus(boolean status) {
        this.status = status;
    }

    public boolean isPossibilidade1() {
        return possibilidade1;
    }

    public void setPossibilidade1(boolean possibilidade1) {
        this.possibilidade1 = possibilidade1;
    }

    public boolean isPossibilidade2() {
        return possibilidade2;
    }

    public void setPossibilidade2(boolean possibilidade2) {
        this.possibilidade2 = possibilidade2;
    }

    public boolean isPossibilidade3() {
        return possibilidade3;
    }

    public void setPossibilidade3(boolean possibilidade3) {
        this.possibilidade3 = possibilidade3;
    }

    public boolean isPossibilidade4() {
        return possibilidade4;
    }

    public void setPossibilidade4(boolean possibilidade4) {
        this.possibilidade4 = possibilidade4;
    }
    
    public boolean prestacao(){
        if((this.getValorPagamento() <= 500.00) && (this.isPossibilidade1() == true)){
            this.status = true;
            this.setEncarregado("Gerente");
            return this.isStatus();
        }
        if((this.getValorPagamento() <= 1500.00) && (this.isPossibilidade2() == true)){
            this.status = true;
            this.setEncarregado("Gerente Geral");
            return this.isStatus();
        }
        if((this.getValorPagamento() <= 5000.00) && (this.isPossibilidade3() == true)){
            this.status = true;
            this.setEncarregado("Diretor Fincanceiro");
            return this.isStatus();
        }
        if((this.getValorPagamento() <= 15000.00) && (this.isPossibilidade4() == true)){
            this.status = true;
            this.setEncarregado("Diretor Geral");
            return this.isStatus();
        }  
        return false;
    }        
}