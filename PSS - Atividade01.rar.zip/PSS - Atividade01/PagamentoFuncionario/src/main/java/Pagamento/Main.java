package Pagamento;

/**
 *
 * @author leou_
 */
public class Main {
    
    public static void main(String args[]){
        Autorizacao autorizacao = new Autorizacao(2400.0, false, true, true, true, true);
        
        System.out.println("Status da compra:" + autorizacao.prestacao());
        
        System.out.println("Cargo Responsavel:" + autorizacao.getEncarregado());
    }
}
